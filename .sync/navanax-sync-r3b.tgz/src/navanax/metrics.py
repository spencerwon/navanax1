"""The metric request contract (docs/06 §3), implemented once.

    MetricRequest = {metric, scope, denomination, transform, interval, range}

Any chart is that tuple. Phase 0 implements `scope = collection`, with an
orthogonal `traits` filter narrowing the token set (docs/08 §4a); token,
peer-group and universe scopes are not implemented yet. This module serves the tuple; the UI never contains
a bespoke calculation. Intervals come from `config/intervals.yaml` (REQ-N-09),
anchored ranges (HTD/DTD/MTD/YTD) use the DISPLAY timezone because "today"
means your today (docs/06 §1.3), and every response carries its basis --
baseline value and time, window, interval, denomination -- so a number can
never be quoted without it (docs/06 §2.2).

STRUCTURE ONLY. Every metric here is an observed quantity: the highest
collection offer seen in an interval, the lowest listing seen, how many sales
happened. No fair value, no smoothing, no wash filtering (wash_filter is
always `raw` and the response says so). Those are assumptions and live in the
layer above (docs/06 §4).

"Is this order still live?" is asked in three places here -- the live book, the
screener and the bid-lifetime panel -- and it is answered in exactly one:
`standing_sql()`, over the `order_lives` relation the normalizer folds
(docs/08 §3.3). Before that relation existed each of the three carried its own
terminator list and none of them handled a revalidate, an untimed terminator or
a duplicate cancel (BUG-049, BUG-050). A trait offer's criteria are matched by
`criteria_cover_sql()` and the guard in its docstring is load-bearing
(BUG-051).

`immediacy_cost` (REQ-F-13a, methodology §3.2): "what you pay to force
time-to-clear to zero by **hitting the standing collection offer**". Note the
word *standing*. Until BUG-20260910-057 this was computed as an interval
extremum -- `MIN(ask)` over a bucket minus `MAX(collection offer)` over the same
bucket -- and the two legs need not ever have coexisted. That is a different
quantity from the one docs/01 §3.2 defines: biased narrow, worse at wider
intervals, and capable of rendering NEGATIVE on the front page, where a KPI
would read as free arbitrage. It is now built from the STANDING book
(`order_lives`), both legs sampled on the same tau, and a negative value is an
alarm rather than a data point. The old behaviour is still reachable as
`book='observed'` and is labelled as such wherever it is used.

**The Operator's decision of 2026-09-10:** floors and lowest-ask lines are built
from STANDING asks only. A bucket with no live ask is a hole, not a zero and not
the last price seen. `book='observed'` exists for comparison, never as the
default.

Undefined -- returned as null, never substituted -- when either leg is absent.
"No bid at any price" is the most important liquidity fact about a collection,
and a chart must show it as a hole, not a guess.

**The standing book is LEFT-TRUNCATED and every standing series says so.** We
only see orders whose placement we witnessed; Argonauts had ~801 standing
listings before recording started (docs/06 §249, quant §0). So the
reconstructed floor is an OVER-estimate of the true floor and the reconstructed
best bid an UNDER-estimate: a stream-only spread is biased WIDE, and it is an
upper bound, not a measurement. `basis.left_truncated` carries this on every
response.
"""

from __future__ import annotations

import bisect
import heapq
import logging
import math
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

log = logging.getLogger("navanax.metrics")

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None  # type: ignore[assignment]

TRANSFORMS = ("ABS", "PCT", "LOG", "DIFF", "BPS")
DENOMS = ("ETH", "USD")
BOOKS = ("standing", "observed")

# REQ-F-19 / Q-V3: below this many observations a percentile is not reported at
# all. A flag next to a number is not a refusal -- docs/00:199 says the system
# SHALL make quoting an unreliable percentile impossible, and a rendered number
# with a warning beside it is exactly what people quote.
#
# REQ-N-09 tension, stated rather than hidden: this is a threshold and thresholds
# belong in config. It lived as a bare `30` inside `bid_lifetimes` before; one
# named constant used by every caller is strictly better than that, and moving it
# to `config/base.yaml` needs a MetricEngine constructor change that this PR was
# told not to make in dashboard.py. Raised for the tech-lead.
MIN_N_FOR_PERCENTILES = 30

# metric id -> (event_type filter, aggregate, price column?, description)
#
# `book`      : the standing-book kind this metric has, if any (STANDING_KINDS).
# `book_default`: which book the metric uses when the caller does not say.
METRICS: dict[str, dict[str, Any]] = {
    "collection_bid":  {"types": ("collection_offer",), "agg": "MAX", "price": True,
                        "book": "collection_bid", "book_default": "standing",
                        "label": "Highest collection offer seen in interval",
                        "standing_label": "Highest STANDING collection offer "
                                          "(time-weighted median over the bucket)"},
    # `top_item_bid` HAS a standing-book kind -- `item_bid` in STANDING_KINDS --
    # and its default is nevertheless `observed`, which is the one metric where
    # those two differ. Tech-lead re-review, 2026-09-10: the `book` key was
    # missing entirely, and three wrong behaviours followed from that one
    # omission. (1) `series(book='standing')` was refused with the reason "it is
    # a count or flow metric", which is false -- it is a price metric with a
    # resting book, and the real reason is leg discipline. (2) The basis printed
    # `book: "n/a (top_item_bid is a count/flow metric...)"`, so the page told the
    # Operator the wrong thing about a line it was drawing. (3) The
    # `observed_book_warning` is gated on `"book" in spec`, so the ONE price line
    # on the Prices panel that is always an interval extremum was the one line
    # carrying no warning that it is one. The default stays `observed`; what
    # changes is that the refusal, the basis and the warning now tell the truth.
    "top_item_bid":    {"types": ("item_received_bid",), "agg": "MAX", "price": True,
                        "book": "item_bid", "book_default": "observed",
                        "label": "Highest item bid seen in interval",
                        "standing_label": "Highest STANDING item bid "
                                          "(time-weighted median over the bucket)"},
    "floor_ask":       {"types": ("item_listed",), "agg": "MIN", "price": True,
                        "book": "ask", "book_default": "standing",
                        "label": "Lowest listing seen in interval",
                        "standing_label": "Lowest STANDING ask "
                                          "(time-weighted median over the bucket)"},
    "sale_price":      {"types": ("item_sold",), "agg": "MEDIAN", "price": True,
                        "label": "Median sale price in interval"},
    "volume":          {"types": ("item_sold",), "agg": "SUM", "price": True,
                        "label": "Sum of sale prices in interval"},
    "sales_count":     {"types": ("item_sold",), "agg": "COUNT", "price": False,
                        "label": "Sales in interval"},
    "listing_count":   {"types": ("item_listed",), "agg": "COUNT", "price": False,
                        "label": "New listings in interval"},
    "bid_count":       {"types": ("item_received_bid", "collection_offer", "trait_offer"),
                        "agg": "COUNT", "price": False, "label": "Bids placed in interval"},
    "cancel_count":    {"types": ("item_cancelled", "order_invalidate"), "agg": "COUNT",
                        "price": False, "label": "Cancellations + invalidations in interval"},
    "event_count":     {"types": None, "agg": "COUNT", "price": False,
                        "label": "All market events in interval"},
    "immediacy_cost":  {"derived": ("floor_ask", "collection_bid"),
                        "book": "spread", "book_default": "standing",
                        "label": "Lowest ask minus highest collection offer (REQ-F-13a)",
                        "standing_label": "STANDING lowest ask minus STANDING highest collection "
                                          "offer, both legs on the same tau (REQ-F-13a, docs/01 §3.2)"},
}

# The standing-book legs `standing_series` can build. Each is one event type,
# one extremum, and whether a trait filter narrows it.
#
# `collection_offer` is deliberately NOT token-scoped: a collection offer carries
# no token and bids on every one of them, so it is the bid that is available on
# whichever token is at the floor. That is the whole of the quant's leg
# discipline for metric 1 -- the bid leg must be a bid on the token at the floor,
# not the global best bid over all tokens, "mixing those populations is how a
# spread goes negative" (quant §1 metric 1). Item bids and trait offers are
# per-token or per-criteria and so are NOT interchangeable with this leg; a bid
# leg that maxes over all three is a different metric (PR-5).
STANDING_KINDS: dict[str, dict[str, Any]] = {
    "ask":            {"event_type": "item_listed", "want": "min", "token_scoped": True,
                       "label": "lowest standing ask"},
    "collection_bid": {"event_type": "collection_offer", "want": "max", "token_scoped": False,
                       "label": "highest standing collection offer"},
    "item_bid":       {"event_type": "item_received_bid", "want": "max", "token_scoped": True,
                       "label": "highest standing item bid"},
}

# Metrics that HAVE a standing-book kind but whose STANDING variant `series()`
# deliberately does not offer yet, with the reason. The reason is returned to the
# caller verbatim, so it has to be true: a refusal that misstates why is worse
# than no refusal, because it is the sentence the next person reasons from.
STANDING_NOT_OFFERED: dict[str, str] = {
    "top_item_bid": (
        "an item bid is PER-TOKEN. A standing 'highest item bid' maxes over bids on "
        "different tokens, which is not interchangeable with a collection-wide leg -- "
        "mixing those populations is how a spread goes negative (quant §1 metric 1 leg "
        "discipline, Operator's decision of 2026-09-10). The union bid leg that would "
        "make it comparable is PR-5. The primitive already exists and is reachable "
        "directly -- standing_series('item_bid', ...) -- it is only the metric DEFAULT "
        "that is deliberately not moved. Ask for it without `book`, or with "
        "book='observed', and read the observed_book_warning in the basis."),
}

# Negative-spread alarms are logged once per (collection, interval, denomination,
# bucket_start) per process. The dashboard re-renders every 10 s and an alarm that
# floods the log is an alarm nobody reads -- but the key used to omit the bucket,
# so once ANY bucket for a collection had crossed, every LATER crossing on that
# collection was swallowed for the life of the process. A dashboard left open
# overnight would log the 09:00 crossing and never mention the 14:00 one. The
# bucket start is in the key so a NEW crossing always logs, while re-rendering the
# SAME crossed bucket stays deduped, which is the flooding the cap was for.
_NEGATIVE_LOGGED: set[tuple[str, str, str, float]] = set()


# ---------------------------------------------------------------------------
# intervals and ranges
# ---------------------------------------------------------------------------
def load_intervals(cfg_path: str | Path) -> dict[str, Any]:
    import yaml
    with Path(cfg_path).open() as fh:
        data = yaml.safe_load(fh) or {}
    out = {"intervals": {}, "anchored": {}}
    for it in data.get("intervals", []):
        out["intervals"][it["id"]] = it
    for ar in data.get("anchored_ranges", []):
        out["anchored"][ar["id"]] = ar
    return out


def _tz(name: str):
    if ZoneInfo is None:
        return timezone.utc
    try:
        return ZoneInfo(name)
    except Exception:  # noqa: BLE001 - unknown zone name: fall back, do not crash a chart
        return timezone.utc


def anchored_start(anchor: str, now: datetime, tz_name: str) -> datetime:
    """HTD/DTD/MTD/YTD start, in the display timezone, returned as UTC."""
    local = now.astimezone(_tz(tz_name))
    if anchor == "hour":
        s = local.replace(minute=0, second=0, microsecond=0)
    elif anchor == "day":
        s = local.replace(hour=0, minute=0, second=0, microsecond=0)
    elif anchor == "month":
        s = local.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    elif anchor == "year":
        s = local.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
    else:
        raise ValueError(f"unknown anchor {anchor!r}")
    return s.astimezone(timezone.utc)


def parse_range(spec: str, intervals: dict[str, Any], now: datetime, tz_name: str) -> tuple[datetime, datetime]:
    """'6h' / '24h' / '7d' / '30d' trailing windows, or an anchored id (DTD...)."""
    if spec in intervals["anchored"]:
        return anchored_start(intervals["anchored"][spec]["anchor"], now, tz_name), now
    units = {"m": 60, "h": 3600, "d": 86400, "w": 604800}
    try:
        n, u = int(spec[:-1]), spec[-1]
        return now - timedelta(seconds=n * units[u]), now
    except (ValueError, KeyError, IndexError) as exc:
        raise ValueError(f"unknown range {spec!r}; use e.g. 1h, 24h, 7d or HTD/DTD/MTD/YTD") from exc


def bucket_of(ts: float, interval: dict[str, Any], tz_name: str) -> float:
    """Start (epoch seconds) of the bucket containing `ts`.

    Fixed-duration intervals shorter than a day bucket in UTC. Days and
    longer bucket on DISPLAY-timezone boundaries, and calendar intervals
    (months, years) use calendar arithmetic -- docs/06 §1.3: a month is not
    30 days.
    """
    if "duration" in interval:
        d = int(interval["duration"])
        if d < 86400:
            return math.floor(ts / d) * d
        # whole days: align to local midnight
        local = datetime.fromtimestamp(ts, tz=_tz(tz_name))
        day0 = local.replace(hour=0, minute=0, second=0, microsecond=0)
        days_per = d // 86400
        epoch_day = (day0 - datetime(1970, 1, 5, tzinfo=day0.tzinfo)).days  # Monday-aligned for weeks
        start_day = day0 - timedelta(days=epoch_day % days_per)
        return start_day.timestamp()
    cal, n = interval.get("calendar"), int(interval.get("n", 1))
    local = datetime.fromtimestamp(ts, tz=_tz(tz_name))
    if cal == "month":
        m0 = ((local.month - 1) // n) * n + 1
        return local.replace(month=m0, day=1, hour=0, minute=0, second=0, microsecond=0).timestamp()
    if cal == "year":
        y0 = (local.year // n) * n
        return local.replace(year=y0, month=1, day=1, hour=0, minute=0, second=0, microsecond=0).timestamp()
    raise ValueError(f"unsupported interval {interval}")


MAX_BUCKETS = 20_000   # 1-minute bars over two weeks; beyond this the chart is noise and the JSON is megabytes


def bucket_grid(start: float, end: float, interval: dict[str, Any], tz_name: str) -> list[float]:
    """Every bucket start in [start, end), observed or not.

    A series is reported on this grid so that an interval with no observation
    is an explicit null -- a hole on the chart -- rather than a missing point
    that the line silently bridges (docs/06 §1.1: a regular-grid series must
    mark its gaps). Steps by the interval for sub-day buckets and by one day
    otherwise, so calendar buckets (months, years) come out of bucket_of.
    """
    step = int(interval["duration"]) if "duration" in interval and int(interval["duration"]) < 86400 else 86400
    if end <= start:
        return []
    if (end - start) / step > MAX_BUCKETS * 4:
        raise ValueError(f"{interval.get('id', '?')} bars over this range is more than {MAX_BUCKETS:,} buckets; choose a larger interval")
    grid: list[float] = []
    t = start
    last = None
    while t < end:
        b = bucket_of(t, interval, tz_name)
        if b != last:
            grid.append(b)
            last = b
        t += step
    if len(grid) > MAX_BUCKETS:
        raise ValueError(f"{len(grid):,} buckets is more than {MAX_BUCKETS:,}; choose a larger interval")
    return grid


# ---------------------------------------------------------------------------
# transforms
# ---------------------------------------------------------------------------
def apply_transform(values: list[float | None], transform: str) -> tuple[list[float | None], dict[str, Any]]:
    """docs/06 §2.2. Baseline = first non-null value in the window."""
    if transform not in TRANSFORMS:
        raise ValueError(f"unknown transform {transform!r}; one of {TRANSFORMS}")
    base_idx = next((i for i, v in enumerate(values) if v is not None), None)
    basis: dict[str, Any] = {"transform": transform, "baseline_index": base_idx,
                             "baseline_value": values[base_idx] if base_idx is not None else None}
    if transform == "ABS" or base_idx is None:
        return list(values), basis
    v0 = values[base_idx]
    out: list[float | None] = []
    for v in values:
        if v is None:
            out.append(None)
        elif transform == "DIFF":
            out.append(v - v0)
        elif transform == "PCT":
            out.append((v - v0) / v0 if v0 else None)
        elif transform == "BPS":
            out.append((v - v0) / v0 * 10_000 if v0 else None)
        elif transform == "LOG":
            out.append(math.log(v / v0) if v0 > 0 and v > 0 else None)
    return out, basis


# ---------------------------------------------------------------------------
# trait filters -- AND across trait types, OR within one (OpenSea's semantics)
# ---------------------------------------------------------------------------
def parse_trait_filter(spec: str | None) -> dict[str, list[str]]:
    """'Background:Blue|Red;Eyes:Laser' -> {'Background': ['Blue','Red'], 'Eyes': ['Laser']}"""
    out: dict[str, list[str]] = {}
    if not spec:
        return out
    for part in spec.split(";"):
        if ":" not in part:
            continue
        t, vals = part.split(":", 1)
        vs = [v.strip() for v in vals.split("|") if v.strip() != ""]
        if t.strip() and vs:
            out[t.strip()] = vs
    return out


def token_filter_sql(collection: str, traits: dict[str, list[str]], alias: str = "e") -> tuple[str, list[Any]]:
    """SQL fragment restricting `alias`.token_id to tokens matching every trait clause."""
    if not traits:
        return "", []
    clauses, args = [], []
    for t, vals in traits.items():
        clauses.append(
            f"{alias}.token_id IN (SELECT token_id FROM traits WHERE collection = ? AND trait_type = ? "
            f"AND value IN ({','.join('?' * len(vals))}))")
        args += [collection, t, *vals]
    return " AND " + " AND ".join(clauses), args


# ---------------------------------------------------------------------------
# trait offers under a filter -- the COVERS rule (dataeng §4.3)
# ---------------------------------------------------------------------------
def criteria_cover_sql(alias: str, traits: dict[str, list[str]]) -> tuple[str, list[Any]]:
    """True iff the criteria-bearing order at `alias` COVERS the filter F.

    C is the offer's criteria set, an AND: it bids on any token holding all of
    them. F is the filter, OR within a trait type and AND across types.

        COVERS  <=>  S(F) subset of S(C)  -- the offer will buy ANY token the
                     filter selects, so it is bid depth for that filter.

    Note the direction: what makes an offer count is not that it is confined to
    the filter, it is that it will buy anything the filter picks. Structurally
    that means every criterion (t, v) in C must be GUARANTEED by F -- F must
    have a clause on `t` whose only permitted value is `v`. A filter of
    `Background: Blue|Red` guarantees nothing about Background, so an offer
    requiring Blue is PARTIAL, not COVERS.

    **The guard is the whole safety of this rule.** An unparsed trait offer has
    no `order_criteria` rows, which makes the NOT EXISTS vacuously true and the
    offer would match every filter and every token -- silently, plausibly, and
    in the direction that manufactures an edge (BUG-051). `criteria_n > 0` is
    what stops it. Numeric criteria cannot be evaluated against the string
    `traits` table, so their verdict is UNKNOWN, and UNKNOWN is not TRUE:
    `criteria_numeric_n = 0` excludes them here and
    `MetricEngine.trait_offer_verdicts` counts them.
    """
    pairs = [(t, list(dict.fromkeys(vs))[0]) for t, vs in traits.items() if len(set(vs)) == 1]
    args: list[Any] = []
    inner = ""
    if pairs:
        guard = " OR ".join("(c.trait_type = ? AND c.value = ?)" for _ in pairs)
        for t, v in pairs:
            args += [t, v]
        inner = f" AND COALESCE({guard}, 0) = 0"
    sql = (f"({alias}.criteria_n > 0 AND COALESCE({alias}.criteria_numeric_n, 0) = 0"
           f" AND NOT EXISTS (SELECT 1 FROM order_criteria c"
           f" WHERE c.run = {alias}.run AND c.seq = {alias}.seq AND c.kind = 'string'{inner}))")
    return sql, args


def criteria_covers(criteria: list[tuple[str, str]], traits: dict[str, list[str]]) -> bool:
    """The same rule in Python, for the verdict report. `criteria` is [(type, value)]."""
    if not criteria:
        return False           # C = {} on a criteria-bearing order is the loud-failure marker
    single = {t: list(set(vs))[0] for t, vs in traits.items() if len(set(vs)) == 1}
    return all(single.get(t) == v for t, v in criteria)


def standing_sql(alias: str, now_ts: float) -> tuple[str, list[Any]]:
    """SQL predicate: the order named by `alias`.order_hash was STANDING at `now_ts`.

    One definition, used by `live_book`, `screener` and `bid_lifetimes`. Before
    `order_lives` there were three (metrics.py had a `dead` subquery in two
    places and a third, different, terminator list in `cancel_count`), and none
    of them handled a revalidate, a NULL-`valid_ts` terminator or a duplicate
    cancel (BUG-050).

        standing(h, t)  <=>  t_place <= t
                             AND exit_reason <> 'unknown'
                             AND (t_term IS NULL OR t_term > t)
                             AND (expiration_ts IS NULL OR expiration_ts > t)

    `unknown` is a life whose terminator we saw but cannot place in time. It is
    excluded from the book AND counted, never silently standing forever.
    """
    return (f"""EXISTS (SELECT 1 FROM order_lives ol
                        WHERE ol.order_hash = {alias}.order_hash
                          AND ol.placement_seen = 1
                          AND ol.t_place IS NOT NULL AND ol.t_place <= ?
                          AND ol.exit_reason <> 'unknown'
                          AND (ol.t_term IS NULL OR ol.t_term > ?)
                          AND (ol.expiration_ts IS NULL OR ol.expiration_ts > ?))""",
            [now_ts, now_ts, now_ts])


# ---------------------------------------------------------------------------
# percentiles -- refused, not flagged, below the minimum n (REQ-F-19, Q-V3)
# ---------------------------------------------------------------------------
def pct(sorted_values: list[float], p: float, *, min_n: int = MIN_N_FOR_PERCENTILES) -> float | None:
    """The p-quantile of an ALREADY SORTED sample, or None below `min_n`.

    `docs/00:199` (REQ-F-19) says the system SHALL make it impossible to quote a
    percentile computed from too few observations. Returning the number with a
    `percentiles_reliable: false` beside it does not make it impossible -- the
    page rendered `p10 / median / p90` unconditionally and appended the warning
    as a string, and a number on screen is a number that gets quoted. None is
    the refusal; the count and the minimum travel with it so the caller can say
    WHY it is missing.
    """
    n = len(sorted_values)
    if n == 0 or n < min_n:
        return None
    return sorted_values[min(n - 1, int(p * n))]


# ---------------------------------------------------------------------------
# the standing book over time: a sweep line, not a per-bucket scan
# ---------------------------------------------------------------------------
def _extremum_segments(live: list[tuple[float, float, float]],
                       want_min: bool) -> list[tuple[float, float, float]]:
    """The running min (or max) of a set of intervals, as constant segments.

    `live` is [(t_from, t_to, price)] already clipped to the window. The result
    is [(t0, t1, value)] -- the value of the extremum over [t0, t1), one entry
    per change, in time order, with no entry for time when nothing stood.

    A sweep line over placements and terminations with a lazily-cleaned heap:
    O(E log E) in the number of order ENDPOINTS, never O(buckets x table). The
    naive alternative -- re-querying the book at every bucket boundary -- is
    O(buckets) full scans, which is how the 29-second query of BUG-040 happened
    on a table two orders of magnitude smaller than this one will be.
    """
    sign = 1.0 if want_min else -1.0
    by_t: dict[float, list[tuple[int, int]]] = {}
    for i, (a, b, _price) in enumerate(live):
        by_t.setdefault(a, []).append((1, i))
        by_t.setdefault(b, []).append((-1, i))
    times = sorted(by_t)
    alive: set[int] = set()
    heap: list[tuple[float, int]] = []
    segs: list[tuple[float, float, float]] = []
    for idx, t in enumerate(times):
        # Apply EVERY event at t before reading the state: standing(h, tau) is
        # `t_place <= tau AND t_term > tau`, so an order placed at t is standing
        # at t and one terminated at t is not, and the two orderings must not
        # race each other when they share a timestamp.
        for typ, i in by_t[t]:
            if typ == 1:
                alive.add(i)
                heapq.heappush(heap, (sign * live[i][2], i))
            else:
                alive.discard(i)
        if idx + 1 >= len(times):
            break
        nxt = times[idx + 1]
        while heap and heap[0][1] not in alive:
            heapq.heappop(heap)
        if heap and nxt > t:
            segs.append((t, nxt, sign * heap[0][0]))
    return segs


def _join_segments(a: list[tuple[float, float, float]], b: list[tuple[float, float, float]],
                   ) -> list[tuple[float, float, float, float]]:
    """[(t0, t1, a_value, b_value)] over the time BOTH legs stood.

    Both inputs are sorted and non-overlapping, so this is a linear merge. This
    is what "both legs on the same tau samples" means mechanically: a bucket's
    spread is only ever computed from an ask and a bid that were simultaneously
    live, which is the property the interval-extremum version did not have.
    """
    out: list[tuple[float, float, float, float]] = []
    i = j = 0
    while i < len(a) and j < len(b):
        a0, a1, av = a[i]
        b0, b1, bv = b[j]
        lo, hi = max(a0, b0), min(a1, b1)
        if hi > lo:
            out.append((lo, hi, av, bv))
        if a1 <= b1:
            i += 1
        else:
            j += 1
    return out


def _bucket_windows(grid: list[float], start: float, horizon: float,
                    interval: dict[str, Any], tz_name: str) -> list[tuple[float, float]]:
    """The observable [lo, hi) of every bucket on the grid.

    A bucket at the edge of the range is only observable over its intersection
    with the query window, and NOTHING is observable past `horizon` (= min(end,
    now)) -- a censored order stands "until further notice", and treating that as
    standing into the future would be imputing the future (docs/06 §4.3). So the
    coverage denominator is the observable width, and the basis reports it.
    """
    out: list[tuple[float, float]] = []
    for i, b in enumerate(grid):
        nxt = grid[i + 1] if i + 1 < len(grid) else _next_bucket_start(b, interval, tz_name)
        out.append((max(b, start), min(nxt, horizon)))
    return out


def _next_bucket_start(b: float, interval: dict[str, Any], tz_name: str) -> float:
    step = int(interval["duration"]) if "duration" in interval else 86400
    t = b + step
    for _ in range(400):                     # a calendar month is at most 31 steps of a day
        nb = bucket_of(t, interval, tz_name)
        if nb > b:
            return nb
        t += step
    return b + step


def _accumulate(segs: list[tuple[float, float, float]], grid: list[float],
                windows: list[tuple[float, float]]) -> dict[int, list[tuple[float, float]]]:
    """Split constant segments at bucket boundaries -> {bucket index: [(seconds, value)]}.

    Total work is O(segments + buckets): a segment spanning k buckets emits k
    pairs, and sum over segments of (1 + duration/step) is bounded by
    (segments + buckets). No segment is ever visited per-bucket-of-the-range.
    """
    out: dict[int, list[tuple[float, float]]] = {}
    for t0, t1, v in segs:
        i = max(0, bisect.bisect_right(grid, t0) - 1)
        while i < len(grid) and grid[i] < t1:
            lo, hi = windows[i]
            a, b = max(t0, lo), min(t1, hi)
            if b > a:
                out.setdefault(i, []).append((b - a, v))
            i += 1
    return out


def _distinct_per_bucket(live: list[tuple[float, float, float]], grid: list[float]) -> list[int]:
    """How many DISTINCT orders stood at any point in each bucket.

    A difference array, so an order standing across ten thousand buckets is one
    increment and one decrement rather than ten thousand of each. This is the
    `n` that travels with every median: project rule 4 -- never a point estimate
    without its count.
    """
    diff = [0] * (len(grid) + 1)
    for a, b, _p in live:
        i = max(0, bisect.bisect_right(grid, a) - 1)
        j = min(len(grid) - 1, bisect.bisect_left(grid, b) - 1)
        if j < i:
            continue
        diff[i] += 1
        diff[j + 1] -= 1
    out, run = [], 0
    for i in range(len(grid)):
        run += diff[i]
        out.append(run)
    return out


def time_weighted_quantile(pairs: list[tuple[float, float]], p: float) -> float | None:
    """The p-quantile of a step function, weighted by how long each value held.

    `pairs` is [(seconds, value)]. On a bot-quoted book the instantaneous
    extremum changes many times inside one bucket and a single extreme is not
    the level (quant §1 metric 1): the value that held for most of the bucket is.
    Convention: the smallest value whose cumulative time reaches `p` of the
    total, which for p = 0.5 is the ordinary weighted median.
    """
    if not pairs:
        return None
    agg: dict[float, float] = {}
    for w, v in pairs:
        agg[v] = agg.get(v, 0.0) + w
    total = sum(agg.values())
    if total <= 0:
        return None
    acc, target = 0.0, p * total
    last = None
    for v in sorted(agg):
        acc += agg[v]
        last = v
        if acc >= target - 1e-9:
            return v
    return last


# ---------------------------------------------------------------------------
# the engine
# ---------------------------------------------------------------------------
class MetricEngine:
    def __init__(self, conn: sqlite3.Connection, intervals: dict[str, Any], tz_name: str) -> None:
        self.conn = conn
        self.intervals = intervals
        self.tz = tz_name

    def _bucketed(self, metric: str, collection: str, denom: str, start: float, end: float,
                  interval: dict[str, Any], traits: dict[str, list[str]] | None = None) -> dict[float, float]:
        spec = METRICS[metric]
        col = "price_usd" if denom == "USD" else "price_eth"
        where = ["e.collection = ?", "e.valid_ts >= ?", "e.valid_ts < ?"]
        args: list[Any] = [collection, start, end]
        if spec["types"]:
            where.append(f"e.event_type IN ({','.join('?' * len(spec['types']))})")
            args.extend(spec["types"])
        if spec["price"]:
            where.append(f"e.{col} IS NOT NULL")
        tf, targs = token_filter_sql(collection, traits or {})
        # Under a trait filter, three kinds of event exist:
        #   token-level (listing, item bid, sale, cancel...) -> must match every clause;
        #   collection_offer (no token_id) -> a bid on EVERY token (C = {}), so it passes;
        #   trait_offer (no token_id) -> passes iff its STORED criteria COVER the
        #     filter (dataeng §4.3). Until 2026-09-09 the criteria were parsed by
        #     nothing and every trait offer was excluded under every filter
        #     (BUG-045); that blanket rule is now an evidence-based verdict, and
        #     the offers it still excludes -- unparsed (criteria_n = 0) and
        #     numeric-criteria -- are counted by trait_offer_verdicts (BUG-051).
        if tf and not (spec["types"] and set(spec["types"]) <= {"collection_offer"}):
            clauses = tf[len(" AND "):]                     # "A AND B AND C"
            cover, cargs = criteria_cover_sql("e", traits or {})
            where.append(f"((e.token_id IS NULL AND e.event_type = 'collection_offer')"
                         f" OR (e.event_type = 'trait_offer' AND {cover})"
                         f" OR ({clauses}))")
            args.extend(cargs)
            args.extend(targs)
        sql = f"SELECT e.valid_ts, e.{col} FROM events e WHERE {' AND '.join(where)} ORDER BY e.valid_ts"
        groups: dict[float, list[float]] = {}
        for ts, v in self.conn.execute(sql, args):
            b = bucket_of(ts, interval, self.tz)
            groups.setdefault(b, []).append(v if spec["price"] else 1.0)
        agg = spec["agg"]
        out: dict[float, float] = {}
        for b, vals in groups.items():
            if agg == "MAX":
                out[b] = max(vals)
            elif agg == "MIN":
                out[b] = min(vals)
            elif agg == "SUM":
                out[b] = sum(vals)
            elif agg == "COUNT":
                out[b] = float(len(vals))
            elif agg == "MEDIAN":
                s = sorted(vals)
                n = len(s)
                out[b] = s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2
        return out

    # -- the standing book ---------------------------------------------------
    def _standing_live(self, kind: str, collection: str, denom: str, start: float,
                       horizon: float, traits: dict[str, list[str]] | None,
                       ) -> list[tuple[float, float, float]]:
        """Every order of `kind` that stood at any point in [start, horizon), as
        [(t_from, t_to, price)] clipped to the window.

        Read off `order_lives`, not `events`: one row per order_hash, with the
        duplicate cancel collapsed, the revalidate honoured and the untimed
        terminator marked `unknown` (BUG-049/050). The predicate here is
        `standing_sql`'s, expressed as an interval rather than a point:

            t_place <= tau  AND  exit_reason <> 'unknown'
            AND (t_term IS NULL OR t_term > tau)
            AND (expiration_ts IS NULL OR expiration_ts > tau)

        so the interval is [t_place, min(t_term, expiration_ts)). An order with
        neither stands to `horizon` and no further -- see `_bucket_windows`.

        A trait filter narrows the token-scoped kinds only. A collection offer
        carries no token and bids on every one of them, so it passes every
        filter; that is not a special case, it is what `C = {}` means.
        """
        spec = STANDING_KINDS[kind]
        col = "price_usd" if denom == "USD" else "price_eth"
        where = ["ol.collection = ?", "ol.event_type = ?", "ol.placement_seen = 1",
                 "ol.t_place IS NOT NULL", "ol.t_place < ?", "ol.exit_reason <> 'unknown'",
                 f"ol.{col} IS NOT NULL",
                 "(ol.t_term IS NULL OR ol.t_term > ?)",
                 "(ol.expiration_ts IS NULL OR ol.expiration_ts > ?)"]
        args: list[Any] = [collection, spec["event_type"], horizon, start, start]
        if traits and spec["token_scoped"]:
            tf, targs = token_filter_sql(collection, traits, alias="ol")
            where.append(tf[len(" AND "):])
            args.extend(targs)
        rows = self.conn.execute(
            f"SELECT ol.t_place, ol.t_term, ol.expiration_ts, ol.{col} FROM order_lives ol "
            f"WHERE {' AND '.join(where)}", args)
        live: list[tuple[float, float, float]] = []
        for t_place, t_term, exp_ts, price in rows:
            ends = [x for x in (t_term, exp_ts) if x is not None]
            t_end = min(ends) if ends else horizon
            a, b = max(t_place, start), min(t_end, horizon)
            if b > a:
                live.append((a, b, price))
        return live

    def standing_series(self, kind: str, collection: str, start: float, end: float,
                        interval: str | dict[str, Any], denom: str = "ETH",
                        traits: dict[str, list[str]] | None = None,
                        now: datetime | None = None) -> dict[str, Any]:
        """The standing book's extremum, per bucket, time-weighted.

        For every bucket on the FULL grid of [start, end): the time-weighted
        median of the lowest standing ask (or the highest standing bid) over the
        bucket, with [p10, p90], `coverage` = seconds the leg stood / observable
        bucket seconds, and `n` = distinct orders that were standing.

        The book is sampled at every event time inside the bucket -- a sweep line
        over placements and terminations -- which is both cheaper and strictly
        more informative than sampling at bucket boundaries. Boundary sampling
        would miss a listing that appeared and was cancelled inside one bucket,
        which on this collection is the majority of them (median bid life 9 s).

        **Median vs percentiles, and why they are treated differently.** The
        median here is the LEVEL of a continuously observed step function -- the
        price that was actually standing for most of the bucket. It is a fact
        with n = 1 (one listing stood, at that price, for that long) and is
        reported. [p10, p90] is a claim about the DISTRIBUTION of that level
        across the bucket, and quant §2.3 is explicit that machine quotes are not
        independent observations; below `MIN_N_FOR_PERCENTILES` distinct orders
        it is refused, not flagged (REQ-F-19). Suppressed buckets are counted in
        the basis.

        Nulls where nothing stood. Never zero: zero is a price, and "no standing
        ask" is not the price zero (Operator's decision, 2026-09-10).
        """
        if kind not in STANDING_KINDS:
            raise ValueError(f"unknown standing kind {kind!r}; one of {sorted(STANDING_KINDS)}")
        if denom not in DENOMS:
            raise ValueError(f"unknown denomination {denom!r}; one of {DENOMS}")
        ispec = self.intervals["intervals"][interval] if isinstance(interval, str) else interval
        now_ts = (now or datetime.now(timezone.utc)).timestamp()
        horizon = min(end, now_ts)
        grid = bucket_grid(start, end, ispec, self.tz)
        spec = STANDING_KINDS[kind]
        live = self._standing_live(kind, collection, denom, start, horizon, traits)
        windows = _bucket_windows(grid, start, horizon, ispec, self.tz)
        segs = _extremum_segments(live, spec["want"] == "min")
        per = _accumulate(segs, grid, windows)
        counts = _distinct_per_bucket(live, grid)

        median: list[float | None] = []
        p10: list[float | None] = []
        p90: list[float | None] = []
        coverage: list[float | None] = []
        stood: list[float] = []
        suppressed = 0
        for i in range(len(grid)):
            pairs = per.get(i, [])
            secs = sum(w for w, _ in pairs)
            width = max(0.0, windows[i][1] - windows[i][0])
            stood.append(secs)
            coverage.append((secs / width) if width > 0 else None)
            median.append(time_weighted_quantile(pairs, 0.5))
            if counts[i] >= MIN_N_FOR_PERCENTILES:
                p10.append(time_weighted_quantile(pairs, 0.10))
                p90.append(time_weighted_quantile(pairs, 0.90))
            else:
                if pairs:
                    suppressed += 1
                p10.append(None)
                p90.append(None)
        return {
            "keys": grid,
            "t": [datetime.fromtimestamp(k, tz=timezone.utc).isoformat() for k in grid],
            "median": median, "p10": p10, "p90": p90,
            "coverage": coverage, "n": counts,
            "standing_seconds": stood,
            "bucket_seconds": [max(0.0, hi - lo) for lo, hi in windows],
            "basis": {
                "book": "standing", "kind": kind, "leg": spec["label"],
                "event_type": spec["event_type"],
                "orders_in_window": len(live),
                "aggregation": "time-weighted median over the bucket, sampled at every "
                               "placement and termination inside it",
                "coverage_denominator": "observable bucket seconds = the bucket clipped to the "
                                        "query window and to now; nothing past now is observable",
                "percentiles_min_n": MIN_N_FOR_PERCENTILES,
                "percentiles_suppressed_buckets": suppressed,
                "left_truncated": True,
                "left_truncation_note": "the standing book contains only orders whose PLACEMENT we "
                                        "witnessed; orders resting before recording started are "
                                        "invisible, so a reconstructed floor is an upper bound and "
                                        "a reconstructed best bid a lower one (quant §0, Q-V9)",
                "as_of": datetime.fromtimestamp(horizon, tz=timezone.utc).isoformat(),
            },
        }

    def standing_spread(self, collection: str, start: float, end: float,
                        interval: str | dict[str, Any], denom: str = "ETH",
                        traits: dict[str, list[str]] | None = None,
                        now: datetime | None = None) -> dict[str, Any]:
        """`immediacy_cost` as docs/01 §3.2 defines it: a STANDING-book spread.

            spread(tau) = lowest standing ask(tau) - highest standing collection offer(tau)

        Both legs on the SAME tau. Reported per bucket as the time-weighted
        median with [p10, p90], with `coverage` = both-legs seconds / observable
        bucket seconds, and null wherever either leg was absent -- "no bid at any
        price" is the liquidity fact, not a missing pixel.

        **Leg discipline (quant §1 metric 1).** The bid leg is a COLLECTION offer
        and nothing else. A collection offer carries no token and applies to
        every one of them, so it is by construction a bid available on whichever
        token is at the floor. Item bids and trait offers are per-token and
        per-criteria: maxing over them would pair the ask on one token with the
        bid on another, and "mixing those populations is how a spread goes
        negative." A bid leg that unions all three is a different metric (PR-5).

        **A negative spread is an alarm, not a data point.** If any tau inside a
        bucket has ask < bid, the whole bucket is null and counted in
        `negative_buckets`: a crossed book means the reconstruction is wrong (a
        stale ask, a misparsed price, a left-truncated leg), and publishing the
        median of the remaining tau would hide it behind a plausible number.
        Project rule 5 -- a surprisingly good result is evidence of a bug.
        """
        ispec = self.intervals["intervals"][interval] if isinstance(interval, str) else interval
        now_ts = (now or datetime.now(timezone.utc)).timestamp()
        horizon = min(end, now_ts)
        grid = bucket_grid(start, end, ispec, self.tz)
        windows = _bucket_windows(grid, start, horizon, ispec, self.tz)
        ask_live = self._standing_live("ask", collection, denom, start, horizon, traits)
        bid_live = self._standing_live("collection_bid", collection, denom, start, horizon, traits)
        ask_segs = _extremum_segments(ask_live, True)
        bid_segs = _extremum_segments(bid_live, False)
        joint = _join_segments(ask_segs, bid_segs)

        spread_segs = [(t0, t1, a - b) for t0, t1, a, b in joint]
        ask_on_joint = [(t0, t1, a) for t0, t1, a, _b in joint]
        bid_on_joint = [(t0, t1, b) for t0, t1, _a, b in joint]
        pct_segs = [(t0, t1, (a - b) / a) for t0, t1, a, b in joint if a]
        neg_segs = [(t0, t1, 1.0) for t0, t1, a, b in joint if a - b < 0]

        acc_spread = _accumulate(spread_segs, grid, windows)
        acc_ask = _accumulate(ask_on_joint, grid, windows)
        acc_bid = _accumulate(bid_on_joint, grid, windows)
        acc_pct = _accumulate(pct_segs, grid, windows)
        acc_neg = _accumulate(neg_segs, grid, windows)
        n_ask = _distinct_per_bucket(ask_live, grid)
        n_bid = _distinct_per_bucket(bid_live, grid)

        raw: list[float | None] = []
        p10: list[float | None] = []
        p90: list[float | None] = []
        coverage: list[float | None] = []
        pctv: list[float | None] = []
        leg_ask: list[float | None] = []
        leg_bid: list[float | None] = []
        negative_buckets = 0
        negative_starts: list[float] = []
        suppressed = 0
        for i in range(len(grid)):
            pairs = acc_spread.get(i, [])
            width = max(0.0, windows[i][1] - windows[i][0])
            both = sum(w for w, _ in pairs)
            coverage.append((both / width) if width > 0 else None)
            if acc_neg.get(i):
                negative_buckets += 1
                negative_starts.append(grid[i])
                for arr in (raw, p10, p90, pctv, leg_ask, leg_bid):
                    arr.append(None)
                continue
            raw.append(time_weighted_quantile(pairs, 0.5))
            leg_ask.append(time_weighted_quantile(acc_ask.get(i, []), 0.5))
            leg_bid.append(time_weighted_quantile(acc_bid.get(i, []), 0.5))
            pctv.append(time_weighted_quantile(acc_pct.get(i, []), 0.5))
            n_eff = min(n_ask[i], n_bid[i])
            if n_eff >= MIN_N_FOR_PERCENTILES:
                p10.append(time_weighted_quantile(pairs, 0.10))
                p90.append(time_weighted_quantile(pairs, 0.90))
            else:
                if pairs:
                    suppressed += 1
                p10.append(None)
                p90.append(None)
        iv_id = interval if isinstance(interval, str) else str(ispec.get("id", "?"))
        # One log line per CROSSED BUCKET, not per (collection, interval, denom).
        # Re-rendering the same crossed bucket every 10 s stays silent; a bucket
        # that crosses for the first time hours later always speaks up.
        fresh = [b for b in negative_starts
                 if (collection, iv_id, denom, b) not in _NEGATIVE_LOGGED]
        if fresh:
            for b in fresh:
                _NEGATIVE_LOGGED.add((collection, iv_id, denom, b))
            log.warning(
                "immediacy_cost: %d newly-seen bucket(s) had a CROSSED standing book (ask < bid) "
                "for %s at %s/%s, starting %s -- returned as null, not charted. A crossed book is "
                "a reconstruction defect (stale ask, misparsed price, left-truncated leg), never "
                "an arbitrage. BUG-20260910-057.",
                len(fresh), collection, iv_id, denom,
                ", ".join(datetime.fromtimestamp(b, tz=timezone.utc).isoformat() for b in fresh[:8])
                + (" ..." if len(fresh) > 8 else ""))
        return {
            "keys": grid,
            "t": [datetime.fromtimestamp(k, tz=timezone.utc).isoformat() for k in grid],
            "median": raw, "p10": p10, "p90": p90, "coverage": coverage,
            "pct_of_ask": pctv, "leg_ask": leg_ask, "leg_bid": leg_bid,
            "n_ask": n_ask, "n_bid": n_bid,
            "basis": {
                "book": "standing", "interval_id": iv_id,
                "negative_buckets": negative_buckets,
                "percentiles_min_n": MIN_N_FOR_PERCENTILES,
                "percentiles_suppressed_buckets": suppressed,
                "coverage_denominator": "both-legs seconds / observable bucket seconds",
                "left_truncated": True,
                "as_of": datetime.fromtimestamp(horizon, tz=timezone.utc).isoformat(),
            },
        }

    def series(self, *, metric: str, collection: str, denomination: str = "ETH",
               transform: str = "ABS", interval: str = "1h", range_: str = "24h",
               now: datetime | None = None, traits: dict[str, list[str]] | None = None,
               gaps: list[tuple[float, float | None]] | None = None,
               book: str | None = None) -> dict[str, Any]:
        """One metric on the full bucket grid of the range.

        A price bucket with no observation is None (undefined). A COUNT/SUM
        bucket with no event is 0.0 -- zero sales in an hour we were listening
        is a fact, not a hole -- EXCEPT inside an ingestion gap, where every
        metric is None: we were not listening, so we do not know (REQ-F-15).
        `gaps` is [(start_ts, end_ts_or_None)] from the landing-zone manifest.

        `book` selects which book a price metric is read off, and the basis
        always says which was used:

          * `'standing'` -- the resting book at each instant, from `order_lives`,
            reported as the time-weighted median over the bucket with [p10, p90],
            `coverage` and `n`. **The default** for `floor_ask`,
            `collection_bid` and `immediacy_cost` (Operator, 2026-09-10).
          * `'observed'` -- the old interval extremum: the lowest ask *seen*
            in the bucket, the highest offer *seen*. Kept reachable and
            labelled, because it answers a different question (what traded
            hands in this interval) and because a comparison line is how the
            size of the correction gets seen. It is NOT the quantity docs/01
            §3.2 defines (BUG-20260910-057).

        A count or flow metric has no resting book, so `book='standing'` on one
        is REFUSED with that reason rather than answered from a book that does
        not exist, and its basis reads `book: "n/a (...)"`.

        `top_item_bid` is refused too, but for a DIFFERENT reason, and the two
        must not be conflated: it is a price metric and it does have a resting
        book (`STANDING_KINDS['item_bid']`). What it does not have is a
        collection-wide leg -- an item bid applies to one token, so a standing
        "highest item bid" maxes over bids on different tokens. That belongs with
        the union bid leg of PR-5. Its default is therefore `observed`, its basis
        says `observed` rather than `n/a`, and it carries the
        `observed_book_warning` like every other observed-book price line. See
        `STANDING_NOT_OFFERED` for the reason the refusal actually returns.
        """
        if metric not in METRICS:
            raise ValueError(f"unknown metric {metric!r}; one of {sorted(METRICS)}")
        if denomination not in DENOMS:
            raise ValueError(f"unknown denomination {denomination!r}; one of {DENOMS}")
        if interval not in self.intervals["intervals"]:
            raise ValueError(f"unknown interval {interval!r}; one of {sorted(self.intervals['intervals'])}")
        if book is not None and book not in BOOKS:
            raise ValueError(f"unknown book {book!r}; one of {BOOKS}")
        now = now or datetime.now(timezone.utc)
        start_dt, end_dt = parse_range(range_, self.intervals, now, self.tz)
        start, end = start_dt.timestamp(), end_dt.timestamp()
        ispec = self.intervals["intervals"][interval]

        spec = METRICS[metric]
        if "book" not in spec:
            if book == "standing":
                raise ValueError(
                    f"{metric!r} has no standing-book variant: it is a count or flow metric, not a "
                    f"resting-book quantity. Ask for it without `book`, or with book='observed'.")
            book_used = f"n/a ({metric} is a count/flow metric, not a book quantity)"
        else:
            book_used = book or spec.get("book_default", "observed")
            if book_used == "standing" and metric in STANDING_NOT_OFFERED:
                raise ValueError(
                    f"{metric!r} has a standing book but series() does not offer the standing "
                    f"variant: {STANDING_NOT_OFFERED[metric]}")
        keys = bucket_grid(start, end, ispec, self.tz)
        legs: dict[str, str] = {}
        extra: dict[str, Any] = {}
        book_basis: dict[str, Any] = {}
        if book_used == "standing" and spec.get("book") == "spread":
            st = self.standing_spread(collection, start, end, ispec, denomination, traits, now)
            raw = list(st["median"])
            parts = {"floor_ask": list(st["leg_ask"]), "collection_bid": list(st["leg_bid"])}
            pct = list(st["pct_of_ask"])
            extra = {"p10": st["p10"], "p90": st["p90"], "coverage": st["coverage"],
                     "n_ask": st["n_ask"], "n_bid": st["n_bid"]}
            book_basis = dict(st["basis"])
            legs = self._spread_legs(traits, standing=True)
        elif book_used == "standing":
            st = self.standing_series(spec["book"], collection, start, end, ispec,
                                      denomination, traits, now)
            raw = list(st["median"])
            parts, pct = {}, None
            extra = {"p10": st["p10"], "p90": st["p90"], "coverage": st["coverage"], "n": st["n"]}
            book_basis = dict(st["basis"])
        elif "derived" in spec:
            a, b = spec["derived"]
            ga = self._bucketed(a, collection, denomination, start, end, ispec, traits)
            gb = self._bucketed(b, collection, denomination, start, end, ispec, traits)
            raw = [(ga[k] - gb[k]) if (k in ga and k in gb) else None for k in keys]
            parts = {"floor_ask": [ga.get(k) for k in keys],
                     "collection_bid": [gb.get(k) for k in keys]}
            pct = [((ga[k] - gb[k]) / ga[k]) if (k in ga and k in gb and ga[k]) else None for k in keys]
            legs = self._spread_legs(traits, standing=False)
        else:
            g = self._bucketed(metric, collection, denomination, start, end, ispec, traits)
            empty = 0.0 if spec["agg"] in ("COUNT", "SUM") else None
            raw = [g.get(k, empty) for k in keys]
            parts, pct = {}, None
        gap_masked = 0
        if gaps and keys:
            widths = [keys[i + 1] - keys[i] for i in range(len(keys) - 1)] + [end - keys[-1]]
            for i, k in enumerate(keys):
                k_end = k + widths[i]
                if any(gs < k_end and (ge is None or ge > k) for gs, ge in gaps):
                    gap_masked += 1                # every bucket we were not listening in, valued or not
                    raw[i] = None
                    if parts:
                        for leg in parts.values():
                            leg[i] = None
                        if pct is not None:
                            pct[i] = None
                    # A standing series has its own arrays and every one of them
                    # is a claim about a window we were not listening in.
                    for key in ("p10", "p90", "coverage"):
                        if key in extra:
                            extra[key][i] = None
                    for key in ("n", "n_ask", "n_bid"):
                        if key in extra:
                            extra[key][i] = 0

        values, basis = apply_transform(raw, transform)
        basis.update(book_basis)
        basis.update({
            "metric": metric,
            "label": (spec.get("standing_label", spec["label"]) if book_used == "standing"
                      else spec["label"]),
            "book": book_used, "collection": collection,
            "denomination": denomination, "interval": interval,
            "range": {"spec": range_, "start": start_dt.isoformat(), "end": end_dt.isoformat()},
            "display_timezone": self.tz,
            "wash_filter": "raw",           # no filter exists yet; say so rather than imply one
            "trait_filter": traits or {},
            "as_of": now.isoformat(),
            "baseline_at": (datetime.fromtimestamp(keys[basis["baseline_index"]], tz=timezone.utc).isoformat()
                            if basis.get("baseline_index") is not None and keys else None),
            "buckets": len(keys),
            "undefined_buckets": sum(1 for v in raw if v is None),
            "gap_masked_buckets": gap_masked,
            "bucket_alignment": ("UTC" if "duration" in ispec and int(ispec["duration"]) < 86400
                                 else f"local midnight ({self.tz})"),
        })
        if legs:
            basis["legs"] = legs
        if book_used == "observed" and "book" in spec:
            tail = ("Kept for comparison; do not quote it as the spread."
                    if spec.get("book") == "spread" else
                    "Kept for comparison; do not quote it as the level of the book.")
            basis["observed_book_warning"] = (
                f"book='observed' on {metric!r} is the INTERVAL EXTREMUM -- the best price SEEN "
                "at any instant in the bucket, from orders that need never have coexisted and need "
                "not have been standing at the end of it. It is not the standing-book quantity "
                "docs/01 §3.2 defines and it is biased optimistic, more so at wider intervals "
                f"(BUG-20260910-057). {tail}")
        out = {"t": [datetime.fromtimestamp(k, tz=timezone.utc).isoformat() for k in keys],
               "v": values, "raw": raw, "basis": basis}
        if parts:
            out["parts"] = parts
            out["pct_of_ask"] = pct
        if extra:
            # The band, the coverage and the counts describe the RAW series and
            # are never transformed: a [p10, p90] in ETH under a PCT transform
            # would be two numbers on a different scale from the line they sit
            # under, which is the kind of chart that gets read wrong once.
            basis["bands_untransformed"] = True
            basis["bands_note"] = (f"p10/p90 are in {denomination} on the raw series; coverage is a "
                                   f"fraction of bucket seconds; n is a count of orders. The "
                                   f"transform applies to the plotted line only.")
        out.update(extra)
        return out

    @staticmethod
    def _spread_legs(traits: dict[str, list[str]] | None, *, standing: bool) -> dict[str, str]:
        """What each leg of the derived spread is, said out loud, every time.

        Only emitted under a trait filter, where the two legs are drawn from
        different populations and the reader has to know it.
        """
        if not traits:
            return {}
        book = "standing " if standing else "observed (interval-extremum) "
        return {
            "floor_ask": f"trait-filtered: {book}lowest ask on tokens matching the filter",
            "collection_bid": f"collection-wide: {book}collection offers carry no token and apply to every "
                              "token. Trait offers do NOT enter this leg -- `collection_bid` is "
                              "collection offers by definition, and a trait-offer bid leg is a "
                              "separate metric. Where a metric does include trait offers (bid_count, "
                              "event_count) they are now matched by the COVER rule on their stored "
                              "criteria; offers with no parsed criteria or with numeric criteria are "
                              "excluded and counted (MetricEngine.trait_offer_verdicts)",
        }

    # -- non-series views ----------------------------------------------------
    def live_book(self, collection: str, now: datetime | None = None, limit: int = 25,
                  traits: dict[str, list[str]] | None = None) -> dict[str, Any]:
        """Orders placed and not since cancelled/invalidated/filled, and unexpired.

        Lifecycle by order_hash. This is the closest thing to "the book right
        now" that the stream supports without a REST snapshot.
        """
        now_dt = now or datetime.now(timezone.utc)
        now_iso = now_dt.isoformat().replace("+00:00", "Z")
        now_ts = now_dt.timestamp()
        standing, sargs = standing_sql("e", now_ts)
        base = f"""SELECT e.valid_at, e.event_type, e.token_id, e.price_eth, e.price_usd,
                          e.maker, e.expiration_at, e.order_hash,
                          (SELECT ol.quantity FROM order_lives ol WHERE ol.order_hash = e.order_hash)
                   FROM events e
                   WHERE e.collection = ? AND e.event_type = ? AND e.order_hash IS NOT NULL
                     AND {standing}"""
        tf, targs = token_filter_sql(collection, traits or {})

        def rows(etype: str, order: str) -> list[dict[str, Any]]:
            extra = tf if etype != "collection_offer" else ""
            cur = self.conn.execute(base + extra + f" ORDER BY e.price_eth {order} LIMIT ?",
                                    (collection, etype, *sargs, *(targs if extra else []), limit))
            keys = ("valid_at", "event_type", "token_id", "price_eth", "price_usd",
                    "maker", "expiration_at", "order_hash", "quantity")
            return [dict(zip(keys, r, strict=True)) for r in cur]
        book = {"as_of": now_iso,
                "asks": rows("item_listed", "ASC"),
                "item_bids": rows("item_received_bid", "DESC"),
                "collection_offers": rows("collection_offer", "DESC")}
        # Depth is units, not rows: a collection offer good for 5 is five units
        # (quant T3b). Carried from the placement by order_lives.
        book["depth"] = {k: sum(max(1, int(r["quantity"] or 1)) for r in v)
                         for k, v in book.items() if isinstance(v, list)}
        return book

    def tape(self, collection: str, limit: int = 50, traits: dict[str, list[str]] | None = None) -> list[dict[str, Any]]:
        tf, targs = token_filter_sql(collection, traits or {})
        cur = self.conn.execute(
            f"""SELECT e.valid_at, e.token_id, e.price_eth, e.price_usd, e.maker, e.taker, e.tx_hash
               FROM events e WHERE e.collection = ? AND e.event_type = 'item_sold'{tf}
               ORDER BY e.valid_ts DESC LIMIT ?""", (collection, *targs, limit))
        return [dict(zip(("valid_at", "token_id", "price_eth", "price_usd", "maker", "taker", "tx_hash"), r, strict=True))
                for r in cur]

    def makers(self, collection: str, start: float, end: float, limit: int = 10) -> dict[str, Any]:
        total = self.conn.execute(
            "SELECT COUNT(*) FROM events WHERE collection=? AND valid_ts>=? AND valid_ts<? AND maker IS NOT NULL",
            (collection, start, end)).fetchone()[0]
        cur = self.conn.execute(
            """SELECT maker, COUNT(*) n,
                      SUM(event_type='item_received_bid') bids,
                      SUM(event_type='item_cancelled') cancels,
                      SUM(event_type='item_listed') listings
               FROM events WHERE collection=? AND valid_ts>=? AND valid_ts<? AND maker IS NOT NULL
               GROUP BY maker ORDER BY n DESC LIMIT ?""", (collection, start, end, limit))
        rows = [dict(zip(("maker", "events", "bids", "cancels", "listings"), r, strict=True)) for r in cur]
        return {"total_events_with_maker": total, "top": rows}

    def bid_lifetimes(self, collection: str, start: float, end: float,
                      kind: str = "item_received_bid") -> dict[str, Any]:
        """How long a bid stands, read off `order_lives`: ONE life per order.

        The old version joined `events` to `events` with no first-termination
        restriction, so an order with two cancel rows produced a cross product
        and `n` was a count of bid x cancel PAIRS, not of bids (BUG-049). It
        also dropped every bid still standing at window end, which biases the
        percentiles short in the opposite direction -- so the net sign of the
        old error is unknown and the new median may move EITHER way. A large
        change here is the expected consequence of two known defects, not a
        discovery.

        Reported with its counts (project rule 4): ended, still-standing
        (censored), untimed terminators (unknown), and the orphan rate -- the
        share of terminations in the window whose placement we never saw, which
        is the direct estimator of how left-truncated this book still is
        (quant metric 12).

        **Percentiles are WITHHELD, not flagged, below `MIN_N_FOR_PERCENTILES`**
        (REQ-F-19, Q-V3). All three -- p10, median and p90 -- are quantiles of a
        duration sample, so all three are refused together; `n`,
        `min_n_for_percentiles` and `percentiles_withheld` travel with the None
        so the caller can say why the number is missing rather than showing a
        number with a warning beside it, which is what people quote.

        The estimator is still naive: censored lives are counted, not modelled.
        Kaplan-Meier with competing risks is PR-8 and reads these same rows.
        """
        ended: list[float] = []
        censored = unknown = at_risk = 0
        for t_place, t_term, reason in self.conn.execute(
                """SELECT t_place, t_term, exit_reason FROM order_lives
                   WHERE collection = ? AND event_type = ? AND placement_seen = 1
                     AND t_place IS NOT NULL AND t_place >= ? AND t_place < ?""",
                (collection, kind, start, end)):
            at_risk += 1
            if reason == "censored":
                censored += 1
            elif reason == "unknown":
                unknown += 1
            elif t_term is not None:
                ended.append(t_term - t_place)
        d = sorted(ended)
        n = len(d)
        terms, orphans = self.conn.execute(
            """SELECT COUNT(*), SUM(placement_seen = 0) FROM order_lives
               WHERE collection = ? AND exit_source = 'observed' AND t_term IS NOT NULL
                 AND t_term >= ? AND t_term < ?""", (collection, start, end)).fetchone()
        orphans = orphans or 0
        return {"n": n,
                "p10_s": pct(d, 0.10), "median_s": pct(d, 0.5), "p90_s": pct(d, 0.9),
                "min_n_for_percentiles": MIN_N_FOR_PERCENTILES,
                "percentiles_reliable": n >= MIN_N_FOR_PERCENTILES,
                "percentiles_withheld": n < MIN_N_FOR_PERCENTILES,
                "kind": kind, "orders_at_risk": at_risk,
                "censored_n": censored, "unknown_terminator_n": unknown,
                "terminations_in_window": terms, "orphan_terminations": orphans,
                "orphan_rate": (orphans / terms) if terms else None,
                "censoring": "counted, not modelled -- percentiles are biased short by "
                             "the censored lives (PR-8 replaces this with Kaplan-Meier)"}

    def criteria_coverage(self, collection: str) -> dict[str, Any]:
        """Every distinct (trait_type, value) in `order_criteria` should exist in `traits`.

        If OpenSea's `trait_name` casing or spelling differs from the metadata's
        `value`, every match silently returns nothing -- a wrong answer that
        looks like a quiet market. Values are stored verbatim on both sides
        precisely so this check can see the difference; the check is what makes
        the difference visible instead of invisible (dataeng §4.2).
        """
        pairs = self.conn.execute(
            """SELECT DISTINCT c.trait_type, c.value FROM order_criteria c
               JOIN events e ON e.run = c.run AND e.seq = c.seq
               WHERE e.collection = ? AND c.kind = 'string'""", (collection,)).fetchall()
        missing = [(t, v) for t, v in pairs if not self.conn.execute(
            "SELECT EXISTS(SELECT 1 FROM traits WHERE collection=? AND trait_type=? AND value=?)",
            (collection, t, v)).fetchone()[0]]
        return {"collection": collection, "distinct_criteria": len(pairs),
                "matched": len(pairs) - len(missing), "missing": len(missing),
                "missing_pairs": [{"trait_type": t, "value": v} for t, v in missing[:50]],
                "alert": bool(missing),
                "note": ("a criterion with no matching trait value can never match a token; "
                         "if this is non-zero the trait table is incomplete or the casing differs")}

    def trait_offer_verdicts(self, collection: str, traits: dict[str, list[str]] | None,
                             start: float, end: float) -> dict[str, Any]:
        """COVERS / PARTIAL / DISJOINT / UNKNOWN / UNPARSED for a filter. Never summed.

        Three verdicts are mutually exclusive and must never be added into one
        depth number (dataeng §4.3): a PARTIAL offer is reported with
        |S(F) n S(C)| and |S(F)|, never as a bare count. Allocating a fraction
        of a PARTIAL offer's quantity as depth models the offerer as
        indifferent among the tokens in reach -- a judgement, and so it belongs
        in ANALYSIS with its assumption declared, never here (docs/06 §4).
        """
        traits = traits or {}
        tf, targs = token_filter_sql(collection, traits, alias="t")
        s_f = {r[0] for r in self.conn.execute(
            f"SELECT t.token_id FROM tokens t WHERE t.collection = ?{tf}", (collection, *targs))}
        covers = disjoint = unknown = unparsed = 0
        partial: list[dict[str, Any]] = []
        for run, seq, oh, price, qty, cn, cnn in self.conn.execute(
                """SELECT run, seq, order_hash, price_eth, quantity, criteria_n, criteria_numeric_n
                   FROM events WHERE collection = ? AND event_type = 'trait_offer'
                     AND valid_ts >= ? AND valid_ts < ?""", (collection, start, end)):
            if cn is None or cn == 0:
                unparsed += 1                       # the loud-failure marker: matches nothing
                continue
            if (cnn or 0) > 0:
                unknown += 1                        # numeric criteria: UNKNOWN is not TRUE
                continue
            crit = self.conn.execute(
                "SELECT trait_type, value FROM order_criteria WHERE run=? AND seq=? AND kind='string'",
                (run, seq)).fetchall()
            if criteria_covers(list(crit), traits):
                covers += 1
                continue
            s_c: set[str] | None = None
            for t, v in crit:
                got = {r[0] for r in self.conn.execute(
                    "SELECT token_id FROM traits WHERE collection=? AND trait_type=? AND value=?",
                    (collection, t, v))}
                s_c = got if s_c is None else (s_c & got)
            overlap = len(s_f & (s_c or set()))
            if overlap:
                partial.append({"order_hash": oh, "price_eth": price, "quantity": qty,
                                "criteria": [{"trait_type": t, "value": v} for t, v in crit],
                                "overlap_tokens": overlap, "filter_tokens": len(s_f)})
            else:
                disjoint += 1
        return {"collection": collection, "trait_filter": traits, "filter_tokens": len(s_f),
                "covers": covers, "partial_n": len(partial), "partial": partial,
                "disjoint": disjoint, "unknown_numeric": unknown, "unparsed": unparsed,
                "note": "COVERS is the only verdict counted as bid depth; the four others are "
                        "reported separately and are never summed into it"}

    def screener(self, collection: str, *, traits: dict[str, list[str]] | None = None,
                 sort: str = "token_id", direction: str = "asc", page: int = 0, page_size: int = 50,
                 denom: str = "ETH", now: datetime | None = None) -> dict[str, Any]:
        """Every token matching the filter, with its traits and its live market state,
        sortable by any column -- token, name, any trait type, lowest ask, highest bid,
        last sale (REQ-F-07). Computed from the store; no REST."""
        col = "price_usd" if denom == "USD" else "price_eth"
        now_dt = now or datetime.now(timezone.utc)
        now_iso = now_dt.isoformat().replace("+00:00", "Z")
        now_ts = now_dt.timestamp()
        tf, targs = token_filter_sql(collection, traits or {}, alias="t")
        toks = self.conn.execute(
            f"SELECT t.token_id, t.name, t.image_url FROM tokens t WHERE t.collection = ?{tf}",
            (collection, *targs)).fetchall()
        ids = {r[0] for r in toks}
        tr: dict[str, dict[str, str]] = {}
        for tid, tt, v in self.conn.execute("SELECT token_id, trait_type, value FROM traits WHERE collection = ?", (collection,)):
            if tid in ids:
                tr.setdefault(tid, {})[tt] = v
        standing, sargs = standing_sql("e", now_ts)      # one definition, shared with live_book
        live = f"""SELECT e.token_id, MIN(e.{col}), MAX(e.{col}) FROM events e
                   WHERE e.collection = ? AND e.event_type = ? AND e.order_hash IS NOT NULL AND e.token_id IS NOT NULL
                     AND {standing} GROUP BY e.token_id"""
        ask = {t: lo for t, lo, _ in self.conn.execute(live, (collection, "item_listed", *sargs))}
        bid = {t: hi for t, _, hi in self.conn.execute(live, (collection, "item_received_bid", *sargs))}
        last_sale: dict[str, tuple[float, str]] = {}
        for t, p, at in self.conn.execute(
                f"""SELECT token_id, {col}, valid_at FROM events WHERE collection = ? AND event_type = 'item_sold'
                    AND token_id IS NOT NULL ORDER BY valid_ts ASC""", (collection,)):
            last_sale[t] = (p, at)
        rows = []
        for tid, name, img in toks:
            ls = last_sale.get(tid)
            rows.append({"token_id": tid, "name": name, "image_url": img, "traits": tr.get(tid, {}),
                         "lowest_ask": ask.get(tid), "highest_bid": bid.get(tid),
                         "last_sale": ls[0] if ls else None, "last_sale_at": ls[1] if ls else None})
        trait_types = sorted({tt for d in tr.values() for tt in d})
        if sort not in ("token_id", "name", "lowest_ask", "highest_bid", "last_sale") and sort not in trait_types:
            sort = "token_id"   # an unknown column is a caller mistake, not a crash and never SQL
        direction = "desc" if direction == "desc" else "asc"

        def key(r: dict[str, Any]):
            if sort == "token_id":
                try:
                    return (0, 0, int(r["token_id"]))
                except ValueError:
                    return (0, 1, r["token_id"])
            if sort in ("lowest_ask", "highest_bid", "last_sale"):
                v = r[sort]
                return (1, 0, 0.0) if v is None else (0, 0, v)
            if sort == "name":
                return (1, 0, "") if not r["name"] else (0, 1, r["name"].lower())
            v = r["traits"].get(sort)
            if v is None:
                return (1, 0, "")
            try:
                return (0, 0, float(v))          # numbers before words, each kind compared with its own
            except ValueError:
                return (0, 1, v.lower())
        rows.sort(key=key, reverse=(direction == "desc"))
        if direction == "desc":
            # keep "no value" rows at the bottom in either direction
            rows.sort(key=lambda r: key(r)[0] == 1)
        total = len(rows)
        page_rows = rows[page * page_size:(page + 1) * page_size]
        return {"total": total, "page": page, "page_size": page_size, "sort": sort, "direction": direction,
                "denomination": denom, "trait_types": trait_types, "as_of": now_iso,
                "trait_filter": traits or {}, "rows": page_rows}

    def event_mix(self, collection: str | None, start: float, end: float) -> list[dict[str, Any]]:
        where = "valid_ts>=? AND valid_ts<?" + (" AND collection=?" if collection else "")
        args: list[Any] = [start, end] + ([collection] if collection else [])
        cur = self.conn.execute(
            f"SELECT event_type, COUNT(*) FROM events WHERE {where} GROUP BY event_type ORDER BY 2 DESC", args)
        return [{"event_type": t, "n": n} for t, n in cur]
